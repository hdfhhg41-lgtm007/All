SONA AI - Stage 1-4. Open in Android Studio (Koala+), sync, Run.
Stage 4 adds: voice/text phone commands (apps, call, SMS, WhatsApp, volume, torch, settings, back/home/lock),
notification reader (opt-in), Phone Controls panel (phone icon in header).
NOT yet: image/camera, background mic service, avatar, voice-call screen.
Untested on device - send build errors and I will fix them.
