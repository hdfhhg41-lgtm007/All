package com.sona.ai
import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App(vm: VM = viewModel()) {
    val hasKey by vm.hasKey.collectAsState()
    if (!hasKey) KeyScreen(vm) else ChatScreen(vm)
}

@Composable
fun KeyScreen(vm: VM) {
    var k by remember { mutableStateOf("") }
    val busy by vm.busy.collectAsState(); val note by vm.note.collectAsState()
    Column(Modifier.fillMaxSize().padding(24.dp).systemBarsPadding(), Arrangement.Center) {
        Text("SONA AI", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(8.dp))
        Text("AI chalane ke liye apni Gemini API key dalein (aistudio.google.com se milti hai).")
        OutlinedTextField(k, { k = it }, Modifier.fillMaxWidth().padding(vertical = 12.dp), label = { Text("Gemini API key") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true)
        note?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button({ vm.saveKey(k) }, enabled = k.isNotBlank() && !busy) { Text(if (busy) "Check ho raha hai..." else "Verify & Save") }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(vm: VM) {
    val ctx = LocalContext.current
    val persona by vm.persona.collectAsState(); val msgs by vm.msgs.collectAsState()
    val busy by vm.busy.collectAsState(); val note by vm.note.collectAsState()
    val owner by vm.owner.collectAsState(); val speakOn by vm.speakReplies.collectAsState()
    var input by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var ownerDlg by remember { mutableStateOf(false) }
    var phoneDlg by remember { mutableStateOf(false) }
    val pending by vm.pending.collectAsState()
    var lang by remember { mutableStateOf("ur-PK") }
    val listener = remember { Listener(ctx, { vm.send(it) }, { vm.note.value = it }) }
    DisposableEffect(Unit) { onDispose { listener.destroy() } }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) listener.start(lang) else vm.note.value = "Mic permission nahi di gayi"
    }
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (owner) "SONA AI (Owner)" else "SONA AI", style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.combinedClickable(onClick = {}, onLongClick = { ownerDlg = true }))
            Spacer(Modifier.weight(1f))
            TextButton({ phoneDlg = true }) { Text("📱") }
            Box {
                TextButton({ menu = true }) { Text(persona.name) }
                DropdownMenu(menu, { menu = false }) {
                    Personas.all.forEach { p -> DropdownMenuItem({ Text(p.name) }, { vm.persona.value = p; menu = false }) }
                }
            }
        }
        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Awaaz jawab"); Switch(speakOn, { vm.speakReplies.value = it })
            Spacer(Modifier.weight(1f))
            val langs = listOf("ur-PK", "hi-IN", "pa-IN", "en-US")
            OutlinedButton({ lang = langs[(langs.indexOf(lang) + 1) % langs.size] }) { Text("Mic: $lang") }
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs, key = { it.id }) { m ->
                val me = m.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (me) Arrangement.End else Arrangement.Start) {
                    Surface(shape = MaterialTheme.shapes.large, tonalElevation = if (me) 6.dp else 2.dp, modifier = Modifier.widthIn(max = 300.dp)) {
                        Column(Modifier.padding(10.dp)) {
                            Text(m.text)
                            if (!me) TextButton({ vm.replay(m.text) }) { Text("🔊 Dobara sunein") }
                        }
                    }
                }
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        note?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 12.dp)) }
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Message likhein...") })
            TextButton({ perm.launch(Manifest.permission.RECORD_AUDIO) }) { Text("🎤") }
            Button({ vm.send(input); input = "" }, enabled = input.isNotBlank() && !busy) { Text("➤") }
        }
    }

    if (ownerDlg) OwnerDialog(vm, owner) { ownerDlg = false }
    if (phoneDlg) PhonePanel(vm) { phoneDlg = false }
    pending?.let { ConfirmDialog(vm, it) }
}

@Composable
fun OwnerDialog(vm: VM, isOwner: Boolean, close: () -> Unit) {
    var key by remember { mutableStateOf("") }
    var model by remember { mutableStateOf(vm.sec.model) }
    var rate by remember { mutableStateOf(vm.speaker.rate) }
    var pitch by remember { mutableStateOf(vm.speaker.pitch) }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = close, confirmButton = { TextButton(close) { Text("Band") } },
        title = { Text("Owner Panel") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!isOwner) {
                    Text(if (vm.sec.ownerKeySet) "Owner Key dalein" else "Pehli baar: apni Owner Key banayein (kam az kam 6 characters)")
                    OutlinedTextField(key, { key = it }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    Button({ if (vm.sec.ownerLogin(key)) vm.owner.value = true else err = "Key galat ya bohat chhoti" }) { Text("Unlock") }
                } else {
                    OutlinedTextField(model, { model = it; vm.sec.model = it.trim() }, label = { Text("Gemini model") }, singleLine = true)
                    Text("Awaaz ki raftaar"); Slider(rate, { rate = it; vm.speaker.rate = it }, valueRange = 0.5f..1.5f)
                    Text("Awaaz ki pitch"); Slider(pitch, { pitch = it; vm.speaker.pitch = it }, valueRange = 0.5f..1.5f)
                    OutlinedButton({ vm.clearHistory() }) { Text("Saari history delete karein") }
                    OutlinedButton({ vm.resetKey(); close() }) { Text("API key hata dein") }
                    OutlinedButton({ vm.owner.value = false; close() }) { Text("Owner logout") }
                }
            }
        })
}
