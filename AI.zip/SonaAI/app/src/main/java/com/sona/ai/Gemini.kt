package com.sona.ai
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.UnknownHostException

object Gemini {
    /** hist: list of ("user"|"model" to text). Never logs the API key. */
    fun chat(key: String, model: String, system: String, hist: List<Pair<String, String>>): Result<String> = try {
        val contents = JSONArray()
        hist.forEach { (r, t) -> contents.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", t)))) }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
        if (code !in 200..299) {
            val m = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault(txt.take(200))
            Result.failure(Exception(when (code) {
                400, 403 -> "API key ya request reject hui ($code): $m"
                404 -> "Model nahi mila: $model (Owner settings me model badlein)"
                429 -> "Quota/rate limit khatam"
                else -> "Error $code: $m"
            }))
        } else {
            val out = JSONObject(txt).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
            if (out.isNullOrBlank()) Result.failure(Exception("Khali jawab (shayad safety filter)")) else Result.success(out)
        }
    } catch (e: UnknownHostException) { Result.failure(Exception("Internet nahi hai")) }
    catch (e: Exception) { Result.failure(Exception("Network error: ${e.message}")) }
}
