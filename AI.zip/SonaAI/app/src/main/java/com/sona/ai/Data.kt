package com.sona.ai
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class Msg(@PrimaryKey(autoGenerate = true) val id: Long = 0, val persona: String, val role: String, val text: String, val ts: Long = System.currentTimeMillis())
@Dao interface MsgDao {
    @Query("SELECT * FROM Msg WHERE persona=:p ORDER BY id") fun all(p: String): Flow<List<Msg>>
    @Insert suspend fun add(m: Msg)
    @Query("DELETE FROM Msg") suspend fun clear()
}
@Database(entities = [Msg::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() { abstract fun dao(): MsgDao }
