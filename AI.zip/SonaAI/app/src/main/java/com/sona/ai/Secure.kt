package com.sona.ai
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest

class Secure(ctx: Context) {
    private val p = EncryptedSharedPreferences.create(
        ctx, "sona_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    var apiKey: String?
        get() = p.getString("k", null)
        set(v) { p.edit().putString("k", v).apply() }
    var model: String
        get() = p.getString("m", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) { p.edit().putString("m", v).apply() }
    var cmdOn: Boolean
        get() = p.getBoolean("cmd", true)
        set(v) { p.edit().putBoolean("cmd", v).apply() }
    var notifRead: Boolean
        get() = p.getBoolean("nr", false)
        set(v) { p.edit().putBoolean("nr", v).apply() }
    var notifHide: Boolean
        get() = p.getBoolean("nh", true)
        set(v) { p.edit().putBoolean("nh", v).apply() }
    val ownerKeySet get() = p.getString("oh", null) != null
    private fun hash(k: String, salt: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + k).toByteArray()).joinToString("") { "%02x".format(it) }
    /** First call sets the Owner Key; later calls verify it. */
    fun ownerLogin(key: String): Boolean {
        if (key.length < 6) return false
        val salt = p.getString("os", null) ?: java.util.UUID.randomUUID().toString().also { p.edit().putString("os", it).apply() }
        val h = p.getString("oh", null)
        if (h == null) { p.edit().putString("oh", hash(key, salt)).apply(); return true }
        return h == hash(key, salt)
    }
}
