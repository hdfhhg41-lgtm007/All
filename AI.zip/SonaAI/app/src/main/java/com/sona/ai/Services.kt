package com.sona.ai
import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.accessibility.AccessibilityEvent

/** Reads notifications aloud (Urdu/Hindi text is spoken with the matching TTS voice). Off by default; content hidden by default. */
class NotifService : NotificationListenerService() {
    private var speaker: Speaker? = null
    private lateinit var sec: Secure
    override fun onCreate() { super.onCreate(); sec = Secure(this); speaker = Speaker(this) }
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!sec.notifRead) return
        val n = sbn.notification
        if (sbn.packageName == packageName || sbn.isOngoing || (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() } catch (e: Exception) { sbn.packageName }
        val hide = sec.notifHide || n.visibility == Notification.VISIBILITY_SECRET
        val say = if (hide) "$app se nayi notification" else {
            val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            listOfNotNull("$app:", title, text).joinToString(". ")
        }
        speaker?.speak(say.take(300))
    }
    override fun onDestroy() { speaker?.shutdown(); super.onDestroy() }
}

/** Only used for global actions (Back/Home/Recents/Notifications/Lock). It does not read screen content. */
class A11yService : AccessibilityService() {
    companion object { @Volatile var instance: A11yService? = null }
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
