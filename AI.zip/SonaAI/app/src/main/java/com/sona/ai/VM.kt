package com.sona.ai
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

@OptIn(ExperimentalCoroutinesApi::class)
class VM(app: Application) : AndroidViewModel(app) {
    val sec = Secure(app)
    private val dao = Room.databaseBuilder(app, Db::class.java, "sona.db").build().dao()
    val speaker = Speaker(app)
    val persona = MutableStateFlow(Personas.all[0])
    val msgs = persona.flatMapLatest { dao.all(it.id) }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val busy = MutableStateFlow(false)
    val note = MutableStateFlow<String?>(null)
    val hasKey = MutableStateFlow(sec.apiKey != null)
    val owner = MutableStateFlow(false)
    val speakReplies = MutableStateFlow(true)

    fun saveKey(k: String) = viewModelScope.launch {
        busy.value = true
        val key = k.trim()
        withContext(Dispatchers.IO) { Gemini.chat(key, sec.model, "Reply OK", listOf("user" to "hi")) }
            .onSuccess { sec.apiKey = key; hasKey.value = true; note.value = null }
            .onFailure { note.value = it.message }
        busy.value = false
    }
    val pending = MutableStateFlow<Out.Confirm?>(null)
    private var pendingPid = "main"
    private suspend fun reply(pid: String, text: String) {
        dao.add(Msg(persona = pid, role = "ai", text = text))
        if (speakReplies.value) speaker.speak(text)?.let { note.value = it }
    }
    fun confirm(body: String) {
        val c = pending.value ?: return
        pending.value = null
        val pid = pendingPid
        val act = when (val a = c.act) { is Act.Sms -> a.copy(body = body); is Act.Wa -> a.copy(body = body); else -> c.act }
        viewModelScope.launch { reply(pid, PhoneCtl.run(getApplication(), act)) }
    }
    fun cancel() {
        pending.value = null
        val pid = pendingPid
        viewModelScope.launch { reply(pid, "Theek hai, cancel kar diya.") }
    }
    fun send(t: String) {
        val key = sec.apiKey ?: return
        if (t.isBlank() || busy.value) return
        val p = persona.value
        viewModelScope.launch {
            if (sec.cmdOn) {
                val out = withContext(Dispatchers.IO) {
                    runCatching { PhoneCtl.handle(getApplication(), t) }.getOrElse { Out.Done("Command fail hui: ${it.message}") }
                }
                if (out !is Out.None) {
                    dao.add(Msg(persona = p.id, role = "user", text = t))
                    when (out) {
                        is Out.Done -> reply(p.id, out.msg)
                        is Out.Confirm -> { pendingPid = p.id; pending.value = out }
                        else -> {}
                    }
                    return@launch
                }
            }
            busy.value = true; note.value = null
            val hist = (msgs.value.takeLast(20).map { (if (it.role == "user") "user" else "model") to it.text } + ("user" to t))
                .dropWhile { it.first == "model" }
            dao.add(Msg(persona = p.id, role = "user", text = t))
            withContext(Dispatchers.IO) { Gemini.chat(key, sec.model, p.prompt, hist) }
                .onSuccess { dao.add(Msg(persona = p.id, role = "ai", text = it)); if (speakReplies.value) speaker.speak(it)?.let { e -> note.value = e } }
                .onFailure { note.value = it.message }
            busy.value = false
        }
    }
    fun replay(t: String) { note.value = speaker.speak(t) }
    fun clearHistory() = viewModelScope.launch { dao.clear() }
    fun resetKey() { sec.apiKey = null; hasKey.value = false; owner.value = false }
    override fun onCleared() { speaker.shutdown() }
}
