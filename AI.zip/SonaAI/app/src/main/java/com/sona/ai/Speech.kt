package com.sona.ai
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class Speaker(ctx: Context) {
    private var ready = false
    private val tts = TextToSpeech(ctx) { ready = it == TextToSpeech.SUCCESS }
    var rate = 1f
    var pitch = 1.05f
    /** Returns an error message, or null on success. */
    fun speak(t: String): String? {
        if (!ready) return "TTS tayyar nahi"
        val loc = when {
            t.any { it in '\u0600'..'\u06FF' } -> Locale("ur", "PK")
            t.any { it in '\u0900'..'\u097F' } -> Locale("hi", "IN")
            t.any { it in '\u0A00'..'\u0A7F' } -> Locale("pa", "IN")
            else -> Locale.US
        }
        val r = tts.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
            return "${loc.displayName} ki awaaz install nahi (Settings > Text-to-speech)"
        tts.setSpeechRate(rate); tts.setPitch(pitch)
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "sona")
        return null
    }
    fun stop() { tts.stop() }
    fun shutdown() { tts.shutdown() }
}

class Listener(private val ctx: Context, private val onText: (String) -> Unit, private val onErr: (String) -> Unit) {
    private var sr: SpeechRecognizer? = null
    fun start(lang: String) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { onErr("Speech recognition is device par available nahi"); return }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) { b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onText) }
                override fun onError(e: Int) { onErr("Mic error code $e") }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang))
        }
    }
    fun destroy() { sr?.destroy() }
}
