package com.sona.ai
import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.TelephonyManager

sealed class Act {
    data class Call(val name: String, val number: String) : Act()
    data class Sms(val name: String, val number: String, val body: String) : Act()
    data class Wa(val name: String, val number: String, val body: String) : Act()
}
sealed class Out {
    data class Done(val msg: String) : Out()
    data class Confirm(val act: Act, val msg: String) : Out()
    object None : Out()
}

/** Understands English / Roman Urdu / Urdu / Hindi phone commands. Returns Out.None when the text is not a command (it then goes to Gemini). */
object PhoneCtl {
    private class NoPerm : Exception()
    private val MULTI = listOf("واٹس ایپ" to "whatsapp", "واٹس اپ" to "whatsapp", "whats app" to "whatsapp", "you tube" to "youtube",
        "یو ٹیوب" to "youtube", "यू ट्यूब" to "youtube", "فیس بک" to "facebook", "وائی فائی" to "wifi", "वाई फाई" to "wifi",
        "wi-fi" to "wifi", "wi fi" to "wifi", "ایس ایم ایس" to "sms", "فون کرو" to "call", "फोन करो" to "call",
        "phone karo" to "call", "fon karo" to "call", "flash light" to "torch")
    private val WORD = mapOf("واٹسایپ" to "whatsapp", "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "वाट्सएप" to "whatsapp",
        "یوٹیوب" to "youtube", "यूट्यूब" to "youtube", "کروم" to "chrome", "क्रोम" to "chrome", "گوگل" to "google", "गूगल" to "google",
        "کیمرہ" to "camera", "کیمرا" to "camera", "कैमरा" to "camera", "گیلری" to "gallery", "गैलरी" to "gallery",
        "میپس" to "maps", "मैप्स" to "maps", "فیسبک" to "facebook", "फेसबुक" to "facebook", "انسٹاگرام" to "instagram", "इंस्टाग्राम" to "instagram",
        "ٹیلیگرام" to "telegram", "टेलीग्राम" to "telegram", "کیلکولیٹر" to "calculator", "कैलकुलेटर" to "calculator",
        "سیٹنگز" to "settings", "سیٹنگ" to "settings", "सेटिंग्स" to "settings", "सेटिंग" to "settings",
        "وائی‌فائی" to "wifi", "वाईफाई" to "wifi", "بلوٹوتھ" to "bluetooth", "ब्लूटूथ" to "bluetooth", "لوکیشن" to "location", "लोकेशन" to "location",
        "والیوم" to "volume", "वॉल्यूम" to "volume", "आवाज़" to "volume", "आवाज" to "volume", "آواز" to "volume", "awaz" to "volume", "awaaz" to "volume", "avaz" to "volume",
        "ٹارچ" to "torch", "टॉर्च" to "torch", "फ्लैशलाइट" to "torch", "flashlight" to "torch",
        "ایس‌ایم‌ایس" to "sms", "एसएमएस" to "sms", "میسج" to "message", "मैसेज" to "message", "پیغام" to "message", "msg" to "message",
        "کال" to "call", "कॉल" to "call", "نوٹیفکیشن" to "notifications", "नोटिफिकेशन" to "notifications", "notification" to "notifications",
        "لاک" to "lock", "लॉक" to "lock", "ہوم" to "home", "होम" to "home", "recent" to "recents")
    private val OPEN = setOf("open", "launch", "start", "kholo", "khol", "kholna", "kholein", "kholen", "kholiye", "chalao", "کھولو", "کھول", "کھولیں", "کھولیے", "چلاؤ", "खोलो", "खोल", "खोलें", "खोलिए", "चलाओ")
    private val CMDV = setOf("karo", "kar", "kardo", "lagao", "laga", "milao", "mila", "do", "کرو", "کر", "لگاؤ", "ملاؤ", "دو", "करो", "कर", "लगाओ", "मिलाओ", "दो")
    private val SENDW = setOf("send", "bhejo", "bhej", "bhejna", "بھیجو", "بھیج", "بھیجنا", "भेजो", "भेज")
    private val CALLW = setOf("call", "dial")
    private val MSGW = setOf("sms", "message")
    private val MARK = setOf("saying", "says", "that", "keh", "kaho", "bolo", "likho", "likh", "کہ", "کہو", "بولو", "لکھو", "لکھ", "कि", "कहो", "बोलो", "लिखो")
    private val GO = setOf("go", "jao", "press", "tap", "dabao", "جاؤ", "دباؤ", "जाओ", "दबाओ")
    private val SHOW = setOf("show", "dikhao", "دکھاؤ", "दिखाओ")
    private val STOP = setOf("app", "ko", "ka", "ki", "ke", "the", "a", "an", "to", "please", "plz", "pls", "de", "dena", "dijiye", "mujhe", "meri", "mera", "me", "for", "number", "contact", "zara", "jaldi", "now",
        "ایپ", "کو", "کا", "کی", "کے", "دیں", "براہ", "مہربانی", "ذرا", "نمبر", "एप", "ऐप", "को", "का", "की", "के", "दें", "कृपया", "ज़रा", "नंबर", "whatsapp") + CMDV + SENDW
    private val UP = setOf("up", "increase", "louder", "barhao", "badhao", "zyada", "zyadah", "زیادہ", "بڑھاؤ", "بڑھائیں", "बढ़ाओ", "बढ़ाएं", "ज़्यादा", "ज्यादा")
    private val DOWN = setOf("down", "decrease", "lower", "kam", "ghatao", "کم", "گھٹاؤ", "कम", "घटाओ")
    private val MUTE = setOf("mute", "silent", "خاموش", "म्यूट")
    private val ON = setOf("on", "jalao", "jala", "chalu", "چالو", "جلاؤ", "चालू", "जलाओ")
    private val OFF = setOf("off", "band", "bujhao", "bujha", "بند", "بجھاؤ", "बंद", "बुझाओ")
    private val BACK = setOf("back", "wapas", "wapis", "واپس", "پیچھے", "वापस", "पीछे")
    private val SETTINGS = listOf("wifi" to Settings.ACTION_WIFI_SETTINGS, "bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
        "location" to Settings.ACTION_LOCATION_SOURCE_SETTINGS, "airplane" to Settings.ACTION_AIRPLANE_MODE_SETTINGS,
        "flight" to Settings.ACTION_AIRPLANE_MODE_SETTINGS, "display" to Settings.ACTION_DISPLAY_SETTINGS,
        "brightness" to Settings.ACTION_DISPLAY_SETTINGS, "sound" to Settings.ACTION_SOUND_SETTINGS,
        "battery" to Settings.ACTION_BATTERY_SAVER_SETTINGS, "settings" to Settings.ACTION_SETTINGS)
    private val WEB = mapOf("youtube" to "https://m.youtube.com", "google" to "https://www.google.com")
    private val KNOWN = setOf("whatsapp", "youtube", "chrome", "google", "camera", "gallery", "maps", "facebook", "instagram", "telegram", "calculator")
    private var torchOn = false
    private const val PUNCT = ",.!?؟،।:;\"'"
    private fun norm(w: String) = w.lowercase().trim { it in PUNCT }
    private val PERM_MSG = "Contacts ki permission chahiye. 📱 Phone Controls me 'Contacts' allow karein."

    fun handle(ctx: Context, raw: String): Out = try { route(ctx, raw) } catch (e: NoPerm) { Out.Done(PERM_MSG) }

    private fun route(ctx: Context, raw: String): Out {
        var s = raw.trim(); MULTI.forEach { (a, b) -> s = s.replace(a, b, ignoreCase = true) }
        val tk = s.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tk.isEmpty() || tk.size > 40) return Out.None
        val tl = tk.map { val n = norm(it); WORD[n] ?: n }
        val set = tl.toSet(); val n = tl.size
        val hasOpen = set.any { it in OPEN }
        val imperative = n == 1 || set.any { it in OPEN || it in CMDV || it in GO || it in ON || it in OFF }

        // Volume
        if (n <= 6) {
            val v = "volume" in set
            val dir = when {
                v && set.any { it in UP } -> AudioManager.ADJUST_RAISE
                v && set.any { it in DOWN } -> AudioManager.ADJUST_LOWER
                set.any { it in MUTE } && (v || n <= 2) -> AudioManager.ADJUST_MUTE
                else -> null
            }
            if (dir != null) return Out.Done(volume(ctx, dir))
        }
        // Torch
        if ("torch" in set && n <= 6 && imperative) {
            val on = when { set.any { it in ON } -> true; set.any { it in OFF } -> false; else -> null }
            return Out.Done(torch(ctx, on))
        }
        // Accessibility global actions
        if (n <= 3) {
            val go = n == 1 || set.any { it in GO || it in CMDV }
            when {
                go && set.any { it in BACK } -> return Out.Done(a11y(AccessibilityService.GLOBAL_ACTION_BACK, "Peeche chale gaye"))
                go && "home" in set -> return Out.Done(a11y(AccessibilityService.GLOBAL_ACTION_HOME, "Home screen par aa gaye"))
                go && "recents" in set -> return Out.Done(a11y(AccessibilityService.GLOBAL_ACTION_RECENTS, "Recent apps khul gayi"))
                go && "lock" in set -> return Out.Done(if (Build.VERSION.SDK_INT >= 28) a11y(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Screen lock kar di") else "Is Android version par screen lock command supported nahi")
                "notifications" in set && (hasOpen || set.any { it in SHOW }) -> return Out.Done(a11y(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Notification panel khol diya"))
            }
        }
        // Settings shortcuts (Android does not let apps toggle Wi-Fi/Bluetooth directly)
        if (n <= 5 && (hasOpen || "settings" in set || set.any { it in ON || it in OFF })) {
            SETTINGS.firstOrNull { it.first in set }?.let { (k, action) ->
                val note = if (set.any { it in ON || it in OFF } && k != "settings") " (Android seedha on/off nahi karne deta, aap yahan se karein)" else ""
                return Out.Done(start(ctx, Intent(action), "${k.replaceFirstChar { it.uppercase() }} settings khul gayi$note", "Ye settings screen nahi khul saki"))
            }
        }
        // Call
        if (set.any { it in CALLW } && (tl.first() in CALLW || (n <= 6 && set.any { it in CMDV }))) {
            val name = tk.filterIndexed { i, _ -> tl[i] !in STOP && tl[i] !in CALLW }.joinToString(" ") { it.trim { c -> c in PUNCT } }
            if (name.isBlank()) return Out.None
            val c = contact(ctx, name) ?: return Out.Done("'$name' contacts me nahi mila.")
            return Out.Confirm(Act.Call(c.first, c.second), "${c.first} (${c.second}) ko call karein?")
        }
        // SMS / WhatsApp message
        val wa = "whatsapp" in set
        if (set.any { it in MSGW || it in SENDW } && (wa || set.any { it in MSGW }) && (tl.first() in MSGW || tl.first() in SENDW || tl.first() == "whatsapp" || set.any { it in SENDW })) {
            val mi = tl.indexOfFirst { it in MARK }
            val headIdx = if (mi >= 0) 0 until mi else tl.indices
            val name = headIdx.filter { tl[it] !in STOP && tl[it] !in MSGW }.joinToString(" ") { tk[it].trim { c -> c in PUNCT } }
            val body = if (mi >= 0) tk.drop(mi + 1).joinToString(" ") else ""
            if (name.isBlank()) return Out.None
            val c = contact(ctx, name) ?: return Out.Done("'$name' contacts me nahi mila.")
            return if (wa) Out.Confirm(Act.Wa(c.first, c.second, body), "WhatsApp message ${c.first} (${c.second}) ko? Send button aap khud dabayenge.")
            else Out.Confirm(Act.Sms(c.first, c.second, body), "SMS ${c.first} (${c.second}) ko? Send button aap khud dabayenge.")
        }
        // Open app
        if (hasOpen) {
            val q = tl.filter { it !in OPEN && it !in STOP }.joinToString("")
            if (q.isBlank()) return Out.None
            launchApp(ctx, q)?.let { return Out.Done(it) }
            if (q in KNOWN) return Out.Done("${q.replaceFirstChar { it.uppercase() }} is phone par install nahi hai.")
        }
        return Out.None
    }

    private fun launchApp(ctx: Context, q: String): String? {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        fun lbl(r: android.content.pm.ResolveInfo) = r.loadLabel(pm).toString().lowercase().replace(" ", "")
        val hit = apps.firstOrNull { lbl(it) == q } ?: apps.firstOrNull { lbl(it).contains(q) }
        if (hit != null) {
            val li = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "${hit.loadLabel(pm)} ka launch intent nahi mila."
            return start(ctx, li, "${hit.loadLabel(pm)} khol diya", "${hit.loadLabel(pm)} nahi khul saka")
        }
        WEB[q]?.let { return start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(it)), "App nahi mili, ${q} browser me khol diya", "${q} nahi khul saka") }
        return null
    }

    private fun contact(ctx: Context, q: String): Pair<String, String>? {
        if (q.count { it.isDigit() } >= 5 && q.all { it.isDigit() || it in "+ -" }) return q to q.filter { it.isDigit() || it == '+' }
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) throw NoPerm()
        val P = ContactsContract.CommonDataKinds.Phone
        var best: Pair<String, String>? = null
        ctx.contentResolver.query(P.CONTENT_URI, arrayOf(P.DISPLAY_NAME, P.NUMBER), "${P.DISPLAY_NAME} LIKE ?", arrayOf("%$q%"), "${P.DISPLAY_NAME} ASC")?.use { c ->
            while (c.moveToNext()) {
                val nm = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                if (best == null) best = nm to num
                if (nm.equals(q, true)) { best = nm to num; break }
            }
        }
        return best
    }

    /** Runs a confirmed action. Messages are only pre-filled; the user must press Send/Call themselves unless CALL_PHONE is granted. */
    fun run(ctx: Context, a: Act): String = when (a) {
        is Act.Call -> {
            val g = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            start(ctx, Intent(if (g) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.fromParts("tel", a.number, null)),
                if (g) "${a.name} ko call lag rahi hai" else "Dialer khul gaya, number bhara hua hai. Call button aap dabayein (CALL permission nahi di gayi).",
                "Call/dialer nahi khul saka")
        }
        is Act.Sms -> start(ctx, Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", a.number, null)).putExtra("sms_body", a.body),
            "SMS app khul gayi, message tayyar hai. Send aap dabayein.", "SMS app nahi mili")
        is Act.Wa -> start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${waNumber(ctx, a.number)}?text=${Uri.encode(a.body)}")),
            "WhatsApp chat khul rahi hai, message tayyar hai. Send aap dabayein. (Agar WhatsApp na khule to number international format me ho)", "WhatsApp nahi khul saka")
    }

    private fun waNumber(ctx: Context, num: String): String {
        val d = num.filter { it.isDigit() || it == '+' }
        if (d.startsWith("+")) return d.drop(1)
        if (d.startsWith("00")) return d.drop(2)
        if (d.startsWith("0")) {
            val cc = when ((ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).simCountryIso) { "pk" -> "92"; "in" -> "91"; else -> null }
            if (cc != null) return cc + d.drop(1)
        }
        return d
    }

    private fun start(ctx: Context, i: Intent, ok: String, fail: String): String = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); ok
    } catch (e: ActivityNotFoundException) { fail } catch (e: SecurityException) { "$fail (permission)" }

    private fun volume(ctx: Context, dir: Int): String = try {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val st = AudioManager.STREAM_MUSIC; val b = am.getStreamVolume(st)
        am.adjustStreamVolume(st, dir, AudioManager.FLAG_SHOW_UI)
        val a = am.getStreamVolume(st); val max = am.getStreamMaxVolume(st)
        if (a == b) "Volume pehle se $b/$max par hai, change nahi hua" else "Volume $b se $a ho gaya (max $max)"
    } catch (e: SecurityException) { "Volume badalne ki ijazat nahi (Do Not Disturb?)" }

    private fun torch(ctx: Context, on: Boolean?): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = try { cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } } catch (e: Exception) { null }
            ?: return "Is phone me flashlight nahi mili"
        val t = on ?: !torchOn
        return try { cm.setTorchMode(id, t); torchOn = t; if (t) "Torch on kar di" else "Torch band kar di" }
        catch (e: Exception) { "Torch nahi chali (camera kisi aur app me use ho raha hai?)" }
    }

    private fun a11y(action: Int, ok: String): String {
        val s = A11yService.instance ?: return "Accessibility service band hai. 📱 Phone Controls se enable karein."
        return if (s.performGlobalAction(action)) ok else "Android ne ye action nahi kiya."
    }
}
