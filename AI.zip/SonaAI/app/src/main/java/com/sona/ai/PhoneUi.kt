package com.sona.ai
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun ConfirmDialog(vm: VM, c: Out.Confirm) {
    var body by remember(c) { mutableStateOf(when (val a = c.act) { is Act.Sms -> a.body; is Act.Wa -> a.body; else -> "" }) }
    AlertDialog(onDismissRequest = { vm.cancel() }, title = { Text("Confirm") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(c.msg)
            if (c.act !is Act.Call) OutlinedTextField(body, { body = it }, label = { Text("Message") })
        } },
        confirmButton = { TextButton({ vm.confirm(body) }) { Text("Haan") } },
        dismissButton = { TextButton({ vm.cancel() }) { Text("Nahi") } })
}

@Composable
fun PhonePanel(vm: VM, close: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    @Suppress("UNUSED_VARIABLE") val t = tick
    var cmd by remember { mutableStateOf(vm.sec.cmdOn) }
    var nr by remember { mutableStateOf(vm.sec.notifRead) }
    var nh by remember { mutableStateOf(vm.sec.notifHide) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }
    fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    val notifOn = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")?.contains(ctx.packageName) == true
    val a11yOn = A11yService.instance != null
    fun open(a: String) { ctx.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    @Composable fun row(label: String, ok: Boolean, btn: String, go: () -> Unit) =
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text((if (ok) "✅ " else "⚠️ ") + label, Modifier.weight(1f))
            if (!ok) OutlinedButton(go) { Text(btn) }
        }

    AlertDialog(onDismissRequest = close, confirmButton = { TextButton(close) { Text("Band") } },
        dismissButton = { TextButton({ tick++ }) { Text("Refresh") } },
        title = { Text("Phone Controls") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Voice/text commands", Modifier.weight(1f)); Switch(cmd, { cmd = it; vm.sec.cmdOn = it }) }
            row("Contacts (naam se call/SMS)", has(Manifest.permission.READ_CONTACTS), "Allow") { launcher.launch(arrayOf(Manifest.permission.READ_CONTACTS)) }
            row("Direct call (warna dialer khulta hai)", has(Manifest.permission.CALL_PHONE), "Allow") { launcher.launch(arrayOf(Manifest.permission.CALL_PHONE)) }
            row("Notification access", notifOn, "Enable") { open(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
            row("Accessibility (back/home/lock)", a11yOn, "Enable") { open(Settings.ACTION_ACCESSIBILITY_SETTINGS) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Notifications bol kar sunao", Modifier.weight(1f)); Switch(nr, { nr = it; vm.sec.notifRead = it }) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Notification ka content chhupao (sirf app ka naam)", Modifier.weight(1f)); Switch(nh, { nh = it; vm.sec.notifHide = it }) }
            Text("Misalen: \"WhatsApp kholo\", \"یوٹیوب کھولو\", \"Ali ko call karo\", \"sms Ali saying kal milte hain\", \"whatsapp message Ali\", \"volume up\", \"torch on\", \"wifi settings\", \"go home\", \"फोन करो Ali\"", style = MaterialTheme.typography.bodySmall)
            Text("Sideload kiya ho to Android 13+ par App info > ⋮ > 'Allow restricted settings' pehle on karna pad sakta hai.", style = MaterialTheme.typography.bodySmall)
        } })
}
